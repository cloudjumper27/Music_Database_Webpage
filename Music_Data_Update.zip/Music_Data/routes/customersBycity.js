var express = require('express');
var router = express.Router();
const sqlite3 = require('sqlite3').verbose();


/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('customersBycity', { title: 'Find customers By city'});
});


router.post('/', function(req, res, next) {
  let db = new sqlite3.Database('./db/chinook.db');
  let sql = "Select * FROM customers WHERE City LIKE  '%" + req.body.city +"%'";

  db.all(sql, [], (err, rows) => {
    if (err) throw err;

    // close the database connection
    db.close();

    console.log(rows);
    res.render('customersBycity', { title: 'Query Customers by City', customers_rows:rows, city_details:req.body.city});
  });
});

module.exports = router;
