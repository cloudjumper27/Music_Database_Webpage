var express = require('express');
var router = express.Router();
const sqlite3 = require('sqlite3').verbose();


/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('employeesByTitle', { title: 'Find Employees By Title'});
});


router.post('/', function(req, res, next) {
  let db = new sqlite3.Database('./db/chinook.db');
  let sql = "Select * FROM employees WHERE Title LIKE  '%" + req.body.title +"%'";

  db.all(sql, [], (err, rows) => {
    if (err) throw err;

    // close the database connection
    db.close();

    console.log(rows);
    res.render('employeesByTitle', { title: 'Query Employees by Title', employees_rows:rows, employee_details:req.body.title});
  });
});

module.exports = router;
