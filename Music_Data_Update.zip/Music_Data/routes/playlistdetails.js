var express = require('express');
var router = express.Router();
const sqlite3 = require('sqlite3').verbose();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('playlistdetails', { title: 'Playlist Details'});
});

router.post('/', function(req, res, next) {
  let db = new sqlite3.Database('./db/chinook.db');
  let sql1 = "SELECT * FROM playlists where playlistid =  ?";
  let sql2 = "SELECT  tracks.trackid, tracks.name, tracks.composer, tracks.unitprice FROM playlists, playlist_track,tracks where playlists.Playlistid = playlist_track.playlistid AND tracks.trackid = playlist_track.trackid and playlists.playlistid = ?";
  db.get(sql1, [req.body.playlistid], (err, row) => {
    if (err) throw err;

    db.all(sql2, [req.body.playlistid], (err, rows) => {
      if (err) throw err;

      // close the database connection
      db.close();
      console.log(row);
      console.log(rows);
      res.render('playlistdetails', { title: 'Playlist Details', row: row, tracks_rows:rows, playlist_id:req.body.playlistid});
    });
  });
});

module.exports = router;
